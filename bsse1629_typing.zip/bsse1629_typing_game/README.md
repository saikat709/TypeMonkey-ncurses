## Command to run the game
```bash
gcc main.c -lncurses -o game && ./game < wordpool.txt && rm -r game
```
